package com.example.intoleranser.DTO

data class EngFoodDTO(
    var id: String,
    var name: String,
    var fodmap: String,
    var category: String,
    var details: Details
)