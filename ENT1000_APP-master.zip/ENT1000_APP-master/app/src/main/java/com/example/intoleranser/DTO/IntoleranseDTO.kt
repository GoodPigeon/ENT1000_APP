package com.example.intoleranser.DTO

import android.graphics.Picture

data class IntoleranseDTO(
    var navn: String,
    var beskrivelse: String,
    var sannsynlighet: Int
)